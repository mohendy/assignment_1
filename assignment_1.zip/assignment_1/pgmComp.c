#include <stdio.h>

#include <stdlib.h>
#include "pgmCheckingValue.h"
#include "pgmErrors.h"
#include "pgmRead.h"
#include "pgmWrite.h"


int compareFile(FILE * fPtrOne,FILE * fPtrTwo, int * lhor, int * cver);

int main()

{

FILE * fPtrOne;
FILE * fPtrTwo;
char pOne[100];
char pTwo[100];
int difference;
int lhor, cver;

printf("Please enter the path of the first file: ");
scanf("%s", pOne);

printf("Please enter the path of the second file: ");
scanf("%s", pTwo);

fPtrOne = fopen(pOne, "r");
fPtrTwo = fopen(pTwo, "r");

if (fPtrOne == NULL || fPtrTwo == NULL)
{

printf("\nFile couldn’t be opened.\n");
printf("Verify if file exists and you have access to read.\n");
exit(EXIT_FAILURE);

}
difference = compareFile(fPtrOne, fPtrTwo, &lhor, &cver);
if (difference == 0)
{

printf("\nTwo files are logically equivalent.");

}

else
{

printf("\nBoth files are logically identical.\n");

printf("Line: %d, col: %d\n", lhor, cver);

}

fclose(fPtrOne);

fclose(fPtrTwo);

return 0;

}

int compareFile(FILE * fPtrOne, FILE * fPtrTwo, int * lhor, int * cver)

{

char firstChar, secondChar;

*lhor = 1;

*cver = 0;

do

{

firstChar = fgetc(fPtrOne);

secondChar = fgetc(fPtrTwo);

if (firstChar == '\n')

{

*lhor += 1;

*cver = 0;

}

if (firstChar != secondChar)

return -1;

*cver += 1;

} while (firstChar != EOF && secondChar != EOF);

if (firstChar == EOF && secondChar == EOF)

return 0;

else

return -1;

}

