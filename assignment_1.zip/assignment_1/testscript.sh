#testscript.sh
clear
echo "Starting shell script..";
ls
ls -l pgmAssemble.c pgmEcho.c pgmTile.c pgmb2a.c pgmComp.c pgmReduce.c pgma2b.c 
gcc pgmAssemble.c -o pgmAssemble
./pgmAssemble
gcc pgmEcho.c -o pgmEcho
./pgmEcho
gcc pgmTile.c -o pgmTile
./pgmTile
gcc pgmb2a.c -o pgmb2a
./pgmb2a
gcc pgmComp.c -o pgmComp
./pgmComp
gcc pgmReduce.c -o pgmReduce
./pgmReduce
gcc pgma2b.c -o pgma2b
./pgma2b
echo "ending of the script";

