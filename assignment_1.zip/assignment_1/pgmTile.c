#include <stdio.h>
#include <stdlib.h>
#include "pgmCheckingValue.h"
#include "pgmErrors.h"
#include "pgmRead.h"
#include "pgmWrite.h"
#include <math.h>
#include <unistd.h>


const char *in_filename = "bigfile.txt";
const char *out_filename = "out_file.bin";

int main()
{

    int ch = 0;

    /* ASCII */
    FILE *in_file = NULL;

    in_file = fopen(in_filename, "r");

    if(!in_file)
    {
         fprintf(stderr, "ERROR: Could not open file %s ... ", in_filename);
         exit(EXIT_FAILURE);
    }

    /* Binary */
    FILE *out_file = NULL;

    out_file = fopen(out_filename, "w+b");

    if(!out_file)
    {
         fprintf(stderr, "ERROR: New file %s, could not be created ... ", out_filename);
         exit(EXIT_FAILURE);

    }

    while(1)
    {
        ch = fgetc(in_file);
            if(ch == EOF)
                break;
            else
               fwrite(in_file, sizeof(char), 1, out_file);
    }

        fclose(in_file);
        fclose(out_file);

    return 0;

}

