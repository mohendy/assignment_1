#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "pgmCheckingValue.h"
#include "pgmErrors.h"
#include "pgmRead.h"
#include "pgmWrite.h"
#include <math.h>


int main(int argc,char*argv[])
{
    FILE *inputFile;
    FILE *outputFile;
    int n;
    if(argc !=4){

        printf("Usage: %s inputFile n outputFile \n", argv[0]);
        return 1;
    }
    n= atoi(argv[2]);

    inputFile = fopen(argv[1],"rb");
    if(inputFile == NULL){
        printf("File not found \n");
        return 1;
    }
    outputFile = fopen(argv[3],"wb");
    if (outputFile == NULL){
        printf("Error opening output file \n");
        return 1;
    }
    // Reducing image by an n factor
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<n;k++){
                for(int l=0;l<n;l++){
                    fgetc(inputFile);
                }
            }
        }
    }
    int c;
    while((c=fgetc(inputFile))!=EOF){
        fputc(c,outputFile);
    }
    fclose(inputFile);
    fclose(outputFile);
    return 0;
}

