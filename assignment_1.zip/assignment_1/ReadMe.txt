To compile the program, execute the "make" command.

To run my test script, type "./testscript.sh"

To run a specific program, please look at the list below:

Usage: ./pgmEcho inputImage.pgm outputImage.pgm

Usage: ./pgmComp inputImage.pgm inputImage.pgm

Usage: ./pgma2b inputImage.pgm outputImage.pgm

Usage: ./pgmb2a inputImage.pgm outputImage.pgm

Usage: ./pgmReduce inputImage.pgm reduction_factor outputImage.pgm

Usage: ./pgmTile inputImage.pgm tiling_factor outputImage_<row>_<column>.pgm

Usage: ./pgmAssemble outputImage.pgm width height (row column inputImage.pgm)+n