#include <stdio.h>
#include <string.h>
// empty constructors
void printErrorStringAndDescription (int errorCode, char* fileNameWithError);
void printUsageString (char* programName);
void printPGMCompOutput (int count);
void printSuccessString (char* programName);
