	#include <stdio.h>
	#include <stdlib.h>
	#include "pgmCheckingValue.h"
    #include "pgmErrors.h"
    #include "pgmRead.h"
    #include "pgmWrite.h"

	#define EXIT_NO_ERRORS 0

	#define EXIT_WRONG_ARG_COUNT 1

	#define EXIT_BAD_INPUT_FILE 2

	#define EXIT_BAD_OUTPUT_FILE 3

	#define MAGIC_NUMBER_RAW_PGM 0x3550

	#define MAGIC_NUMBER_ASCII_PGM 0x3250

	#define MIN_IMAGE_DIMENSION 1

	#define MAX_IMAGE_DIMENSION 65536

	#define MAX_COMMENT_LINE_LENGTH 128

	int main( char **argv){

	unsigned char magic_number[2] = {'0','0'};
	unsigned short *magic_Number = (unsigned short *) magic_number;

	char *commentLine =NULL;
	unsigned int width = 0, height = 0;

	unsigned int maxGray = 255;
	unsigned char *imageData = NULL;
	FILE *inputFile =fopen(argv[1],"r");
	if (!inputFile) return EXIT_BAD_INPUT_FILE;
	magic_number[0] = getc(inputFile);
	magic_number[1] = getc(inputFile);
	if (*magic_number != MAGIC_NUMBER_ASCII_PGM) {
	fclose(inputFile);
	 printf("file created successfully!\n");
	return EXIT_BAD_INPUT_FILE;}
	int scanCount = fscanf(inputFile," ");
	char nextChar = fgetc(inputFile);
	if (nextChar == '#') {
	commentLine = (char*) malloc(MAX_COMMENT_LINE_LENGTH);
	 char *commentString=fgets(commentLine,MAX_COMMENT_LINE_LENGTH,inputFile);
	 if (!commentString){
	 free(commentLine);
	fclose(inputFile);

	printf("ERROR!\n");
	return EXIT_BAD_INPUT_FILE;

	 }
	}
	}
