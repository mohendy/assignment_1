#include <stdio.h>
#include <stdlib.h>
#include "pgmCheckingValue.h"
#include "pgmErrors.h"
#include "pgmRead.h"
#include "pgmWrite.h"
#include <math.h>

int main(int argc, char*argv[])
{
    FILE*fp1, *fp2;
    int width, height;
    int i,j,k;
    // open input and output files
    fp1 = fopen(argv[1],"rb");
    fp2 = fopen(argv[2],"wb");

    width = atoi(argv[3]);
    height = atoi(argv[4]);

    unsigned char image[width*height*3];

    for(int i=0;i<height;i++){
        for(int j=0;j<width;j++){
            for(int k=0;k<3;k++){
                image[(i*width+j)*3+k]=fgetc(fp1);
            }
        }
    }

    fputc((width & 0xFF00)>>8, fp2);
    fputc((width & 0x00FF), fp2);
    fputc((height & 0xFF00)>>8, fp2);
    fputc((height & 0x00FF), fp2);

   for(int i=0;i<height;i++){
        for(int j=0;j<width;j++){
            for(int k=0;k<3;k++){
                fputc(image[(i*width+j)*3+k],fp2);
            }
        }
    }
    fclose(fp1);
    fclose(fp2);
    return 0;
}


